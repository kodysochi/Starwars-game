import time
import random
from console_functions import clear
import inventory
from combat import training_drill, boss_battle



                                #        APPARTMENT ON CORUSCANT        #


def coruscant_puzzle(user_name):
    clear()

    user_choice2 = None
    print("Looking around your apartment everything looks sleek and modern")
    time.sleep(2)
    print("\nLooking in from the entrance on your right is a kitchen")
    time.sleep(2)
    print("\nStrait ahead is an open living area with a couch, coffee table, and a nice rug")
    time.sleep(2)
    print("\nTo your left is a hallway leading to your bedroom")
    time.sleep(2)
    print("\nInside your bedroom you see a bathroom to your left and a bed in the middle")
    time.sleep(2)
    print("\nNext to the bed is your dresser")
    time.sleep(2)
    print("\n\nWhat to do\n\n1) Explore the Kitchen\n2) Explore the living room\n3) Search the dresser\n4) Sleep\n5) Leave apartment")
    while user_choice2 != "out":
        user_choice2 = input()


        #A bunch of info about your appartment + some money on the dresser
        if user_choice2 == "1":
            clear()
            print("You enter the kitchen")
            time.sleep(2)
            print("\nIt still smells of the deep-fried nuna legs you made")
            time.sleep(2)
            print("\nYour fridge is almost empty.... HMMMMM if you weren't about to go on an adventure you would need to go shopping")
            time.sleep(4)
            print("\n\nWhat to do\n\n1) Explore the Kitchen\n2) Explore the living room\n3) Search the dresser\n4) Sleep\n5) Leave apartment")
        
        elif user_choice2 == "2":
            clear()
            print("The holo projector still seems to be broken")
            time.sleep(2)
            print("Hope you don't need to communicate to anyone")
            time.sleep(2)
            print("\nThere is some cups on the coffee table")
            time.sleep(2)
            print("Maybe someday you can afford the crystal glass instead")
            time.sleep(4)
            print("\n\nWhat to do\n\n1) Explore the Kitchen\n2) Explore the living room\n3) Search the dresser\n4) Sleep\n5) Leave apartment")

        #dresser has money
        elif user_choice2 == "3":
            if inventory.dresser == True:
                clear()
                print("You find all your clothes neatly folded except for one of your clokes")
                time.sleep(2)
                print("\nYou start to fold the cloak and you notice some galactic credit in the pocket")
                time.sleep(2)
                print("\nYou grab the money and finish folding the cloak")
                time.sleep(2)
                inventory.dresser = False
                inventory.money += 75
                print("\n\n\n+ $75")
                time.sleep(2)
                clear()
                print("You find all you clothes neatly folded except for one of your clokes\n\nYou start to fold the cloak and you notice some galactic credit in the pocket\n\nYou grab the money and finish folding the cloak")
                print("\n\nWhat to do\n\n1) Explore the Kitchen\n2) Explore the living room\n3) Search the dresser\n4) Sleep\n5) Leave apartment")
            else:
                clear()
                print("All the clothes are still neatly folded")
                time.sleep(3)
                clear()
                print("\n\nWhat to do\n\n1) Explore the Kitchen\n2) Explore the living room\n3) Search the dresser\n4) Sleep\n5) Leave apartment")

        elif user_choice2 == "4":
            clear()
            print("You lay down for a nap")
            time.sleep(2)
            clear()
            time.sleep(4)
            print("You are well rested")
            time.sleep(2)
            print("\n\nWhat to do\n\n1) Explore the Kitchen\n2) Explore the living room\n3) Search the dresser\n4) Sleep\n5) Leave apartment")
                
        elif user_choice2 == "5":
            clear()
            print("You leave your apartment")
            time.sleep(2)
            if inventory.unknown_map == False:
                print("\n\nWhat to do\n\n1) Fly to Hoth\n2) Fly to Kashyyk\n3) Fly to Tatooine\n4) Fly to Mustafar\n5) Look around")
            else:
                print("\n\nWhat to do\n\n1) Fly to Hoth\n2) Fly to Kashyyk\n3) Fly to Tatooine\n4) Fly to Mustafar\n5) Look around\n6) Fly into the unknown regions to Ilum")
            user_choice2 = "out"
        
        
        else:
             print("Not a valid input")   
                                   
                           
            
            
            


            
            
                            #        VENDER AND JOB SITE FOR TATOOINE        #



def tatooine_puzzle(user_name):
    clear()

    user_choice2 = None
    print("As you look around you see a small village in the sand")
    time.sleep(2)
    print("\nYou head towards the village and find it has around 10 residents")
    time.sleep(2)
    print("\nIn the center you see larger building made of sandstone")
    time.sleep(2)
    print("\nInside on your left you see a vender and on your right you see a job board")
    time.sleep(2)
    print("\n\nWhat to do?\n\n1) Approach the vender\n2) Investigate the job board\n3) Go back to your ship")
    while user_choice2 != "out":
        user_choice2 = input()

        #Enters the shop loop to deside what to buy and modify the inventoy accordingly
        if user_choice2 == "1":
            clear()
            
            user_choice3 = None
            print("After some quick introductions")
            time.sleep(3)
            clear()
            print("\nAhhh {}, Take a look around, see anything you like we cant talk price".format(user_name))
            time.sleep(3)
            print("\n\nYou have ${}.\n\n1) Buy iron bar - $50\n2) Buy Aluminum alloy - $100\n3) Buy titanium - $150\n4) Exit the shop".format(inventory.money))
            while user_choice3 != "out":
                user_choice3 = input()
                
                if user_choice3 == "1":
                    if inventory.money >= 50:
                        #adds iron and takes money out of the inventory 
                        inventory.iron += 1
                        #clear the chat and repritns the options with the new money in inv
                        clear()
                        print("\nThank you for your purchase\n\n1 iron bar added. You now have {} iron bars".format(inventory.iron))
                        inventory.money -= 50
                        print("\n\nYou have ${}.\n\n1) Buy iron bar - $50\n2) Buy  Aluminum alloy - $100\n3) Buy titanium - $150\n4) Exit the shop".format(inventory.money))
                    else:
                        print("You don't have the funds.")
                        
                
                
                elif user_choice3 == "2":
                    if inventory.money >= 100:
                        #adds  Aluminum and takes money out of the inventory 
                        inventory.aluminium += 1
                        #clear the chat and repritns the options with the new money in inv
                        clear()
                        print("\nThank you for your purchase\n\n1  Aluminum alloy added, You now have {} aluminum alloy".format(inventory.aluminium))
                        inventory.money -= 100
                        print("\n\nYou have ${}.\n\n1) Buy iron bar - $50\n2) Buy  Aluminum alloy - $100\n3) Buy titanium - $150\n4) Exit the shop".format(inventory.money))
                    else:
                        print("You don't have the funds.")

                
                
                elif user_choice3 == "3":
                    if inventory.money >= 150:
                        #adds Titanium and takes money out of the inventory 
                        inventory.titanium += 1
                        #clear the chat and repritns the options with the new money in inv
                        clear()
                        print("\nThank you for your purchase\n\n1 Titanium added, You now have {} titanium alloy".format(inventory.titanium))
                        inventory.money -= 150
                        print("\n\nYou have ${}.\n\n1) Buy iron bar - $50\n2) Buy  Aluminum alloy - $100\n3) Buy titanium - $150\n4) Exit the shop".format(inventory.money))
                    else:
                        print("You don't have the funds.")
                
                
                
                elif user_choice3 == "4":
                    print("You exit the shop")
                    time.sleep(3)
                    clear()
                    print("What to do?\n\n1) Approach the vender\n2) Investigate the job board\n3) Go back to your ship")
                    user_choice3 = "out"
                else:
                    print("Not a valid input")



        #enter the loop for making money
        elif user_choice2 == "2":
            clear()


            user_choice3 = None
            print("You walk up to the job board and examine the postings")
            time.sleep(2)
            print("\nMost of the jobs are difficult engineering posts, however one post catches your eye")
            time.sleep(2)
            print("\nFind and bring Black Melons to Kabe. $25 per Melon")
            time.sleep(2)
            print("\n\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")
            while user_choice3 != "out":
                user_choice3 = input()

                #Comb the desert for Black Melons enter the loot table for items you can find if any
                if user_choice3 == "1":
                    clear()

                    print("You wander out into the desert in search of Black Melons")
                    time.sleep(2)
                    
                    #picks a random number and depending on the number it will drop an item
                    drop = random.randint(0, 100)

                    #Rare drop
                    if 0 <= drop < 5:
                        print("\n\nIts your lucky day!!!!!\nSomeone has dropped their coin pouch")
                        time.sleep(2)
                        print("\n\n\n+ $300")
                        inventory.money += 300
                        time.sleep(1.5)
                        clear()
                        print("You wander out into the desert in search of Black Melons\n\n\nIts your lucky day!!!!!\nSomeone has dropped their coin pouch")
                        print("You now have ${}".format(inventory.money))
                        time.sleep(2)
                        print("\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")

                    #uncomen drop you find nothing
                    elif 5 <= drop < 25:
                        #adding differing diolog
                        x = random.randint(1, 3)
                        if x == 1:
                            print("\nAfter wandering around for a while the sun is starting to set.")
                            time.sleep(2)
                            print("\nYou head back without finding anything")
                            time.sleep(2)
                            print("\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")
                        elif x == 2:
                            print("\nYou search the sand and find a lump")
                            time.sleep(2)
                            print("\nYou dig up a broken pot. It must have fallen of a speeder")
                            time.sleep(2)
                            print("\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")

                        elif x == 3:
                            print("\nYou start to head out and you spot some Tusken Raiders")
                            time.sleep(2)
                            print("\nThey have claimed this spot today. try again tomorrow")
                            time.sleep(2)
                            print("\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")
                    
                    #Commen drop the black melon                  
                    elif 25 <= drop < 101:
                        #adding differing dialogue
                        y = random.randint(1, 3)
                        if y == 1:
                            print("\nYou have traveled a long ways")
                            time.sleep(2)
                            print("\nFor some reason you feel the sand is right here and start to dig")
                            time.sleep(2)
                            print("\nOnly a short ways under the sand you find a Black Melon")
                            time.sleep(2)
                            print("\n\n\n + 1 Black Melon")
                            inventory.melon += 1
                            time.sleep(2)
                            clear()
                            print("You wander out into the desert in search of Black Melons\n\nYou have traveled a long ways\n\nFor some reason you feel the sand is right here and start to dig\n\nOnly a short ways under the sand you find a Black Melon")
                            print("You now have {} Black Melons".format(inventory.melon))
                            print("\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")
                        elif y == 2:
                            print("\nShortly after you left town you see a small dark spot in the sand")
                            time.sleep(2)
                            print("\nAs you get closer you realize it's a Black Melon")
                            time.sleep(2)
                            print("\n\n\n + 1 Black Melon")
                            inventory.melon += 1
                            time.sleep(2)
                            clear()
                            print("You wander out into the desert in search of Black Melons\n\nShortly after you left town you see a small dark spot in the sand\n\nAs you get closer you realize it's a Black Melon")
                            print("You now have {} Black Melons".format(inventory.melon))
                            print("\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")
                        elif y == 3:
                            print("\nAfter a long day of looking you start to head back")
                            time.sleep(2)
                            print("\nOn your way back you spot a Black Melon")
                            time.sleep(2)
                            print("\n\n\n+ 1 Black Melon")
                            inventory.melon += 1
                            time.sleep(2)
                            clear()
                            print("You wander out into the desert in search of Black Melons\n\nAfter a long day of looking you start to head back\n\nOn your way back you spot a Black Melon")
                            print("You now have {} Black Melons".format(inventory.melon))
                            print("\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")

                
                
                #Selling your finds to Kabe
                elif user_choice3 == "2":
                    clear()

                    user_choice4 = None
                    print("You enter a small hut on the outskirts of town")
                    time.sleep(2)
                    print("\nInside you see a small humanoid creature dressed in a red long sleeve shirt with a black vest on. He has a bat like face and ears with large beady black eyes")
                    time.sleep(2)
                    print("\nKabe seems really excited to get a drink")
                    time.sleep(2)
                    print("\nYou have {} Black melons and ${}".format(inventory.melon, inventory.money))
                    print("\n\nWhat to do\n\n1) Sell 1 of your Black Melons\n2) Leave the building")
                    while user_choice4 != "out":
                        user_choice4 = input()

                        if user_choice4 == "1":
                            if inventory.melon >= 1:
                                inventory.melon -= 1
                                inventory.money += 50
                                print("\n\n\n- 1 Balck Melon")
                                time.sleep(.5)
                                print("+ $50")
                                time.sleep(1.5)
                                clear()
                                print("You enter a small hut on the outskirts of town\n\nInside you see a small humanoid creature dressed in a red long sleeve shirt with a black vest on. He has a bat like face and ears with large beady black eyes\n\nKabe seems really excited to get a drink\n\nYou have {} Black melons and ${}".format(inventory.melon, inventory.money))
                                print("\n\nWhat to do\n\n1) Sell 1 of your Black Melons\n2) Leave the building")
                            else:
                                print("You dont have any melons")
                        elif user_choice4 == "2":
                            clear()
                            print("You leave the building and head back the the town center")
                            time.sleep(2)
                            clear()
                            print("\n\nWhat to do\n\n1) Try and find Black Melons\n2) Go to Kabe\n3) Leave the job board")
                            user_choice4 = "out"
                        else:
                            print("Not a valid input")


                #Going back
                elif user_choice3 == "3":
                    clear()
                    print("You walk away from the job board")
                    time.sleep(2)
                    clear()
                    print("\n\nWhat to do?\n\n1) Approach the vender\n2) Investigate the job board\n3) Go back to your ship")
                    user_choice3 = "out"
                
                else:
                    print("Not a valid input")
        
        

        #heading back to ship
        elif user_choice2 == "3":
            clear()
            print("You head back to your ship")
            time.sleep(2)
            clear()
            print("\n\nWhat to do\n\n1) Fly to naboo\n2) Fly to Coruscant\n3) Fly to Formos\n4) Look around")
            user_choice2 = "out"

        else:
            print("Not a valid input")
                            





                                #        FORAGING LIGHTSABER MUSTAFAR        #

def mustafar_puzzle(user_name):
    clear()

    user_choice2 = None
    print("A dark building is sticking out of the side of a volcano")
    time.sleep(2)
    print("\nInside the building you see a large forage that is getting heated by the lava below")
    time.sleep(2)
    print("\n\nWhat to do\n\n1) Create a lightsaber hilt\n    2 iron, 3 aluminum, 1 titanium\n    *You will need 2\n\n2) Create a lightsaber\n    2 Hilts, 1 Kyber crystal\n\n3) Go back to your ship")
    while user_choice2 != "out":
        user_choice2 = input()

        #hilt foraging
        if user_choice2 == "1":
            if inventory.iron >= 2 and inventory.aluminium >= 3 and inventory.titanium >= 1:
                clear()
                print("You place the metal into a thick bucket")
                time.sleep(2)
                print("\nCarfully you move the bucket into the forage")
                time.sleep(2)
                print("\nAs the metal melts it starts to melt together creating an alloy")
                time.sleep(2.5)
                print("\nQuickly you move the bucket to a cast and pour it in")
                inventory.iron -= 2
                inventory.aluminium -= 3
                inventory.titanium -= 1
                inventory.lightsaber_handle += 1
                time.sleep(2)
                print("\n\n\n+ 1 Lightsaber hilt")
                time.sleep(2)
                clear()
                print("You place the metal into a thick bucket\n\nCarfuly you move the bucket into the forage\n\nAs the metal melts it starts to melt together creating an alloy\n\nQuickly you move the bucket to a cast and pour it in")
                print("Mustafar\n\nWhat to do\n\n1) Create a lightsaber hilt\n    2 iron, 3 aluminum, 1 titanium\n    *You will need 2\n\n2) Create a lightsaber\n    2 Hilts, 1 Kyber crystal\n\n3) Go back to your ship")

            else:
                print("\n\nYou lack the materials in order to create a Lightsaber hilt")

        #lightsaber foraging
        elif user_choice2 == "2":
            if inventory.lightsaber_handle >= 2 and inventory.kyber_crystal == True:
                clear()
                print("Using the force you take out and lift the hits and the kyber crystal into the air")
                time.sleep(2.5)
                print("\nYou align the items so that the crystal is in the middle")
                time.sleep(2.5)
                print("\nYou push the parts together encompassing the crystal in the core")
                time.sleep(2.5)
                inventory.lightsaber = True

                #determines if your a jedi master or not
                if inventory.user_level < 20:
                    inventory.kyber_crystal_color = "blue"
                elif inventory.user_level >= 20:
                    inventory.kyber_crystal_color = "green"

                print("\n\n\n+ 1 {} Lightsaber".format(inventory.kyber_crystal_color))
                time.sleep(2)
                clear()
                print("Using the force you take out and lift the hits and the kyber crystal into the air\n\nYou align the items so that the crystal is in the middle\n\nYou push the parts together encompassing the crystal in the core")
                print("Mustafar\n\nWhat to do\n\n1) Create a lightsaber hilt\n    2 iron, 3 aluminum, 1 titanium\n    *You will need 2\n\n2) Create a lightsaber\n    2 Hilts, 1 Kyber crystal\n\n3) Go back to your ship")
            else:
                print("\n\nYou lack the material inorder to create a Lightsaber")
            
        elif user_choice2 == "3":
            clear()
            print("You walk back across the volcanic rock to your ship")
            time.sleep(2)
            print("Mustafar")
            print("\n\nWhat to do\n\n1) Fly to Hoth\n2) Fly to Coruscant\n3) Fly to Naboo\n4) Look around")
            user_choice2 = "out"

        else:
            print("\nNot a valid input")




               
                
                
                        ###        finding of the map NABOO        ###




def naboo_puzzle(user_name):
    clear()

    user_choice2 = None
    print("The city is large with turquoise domed roofs")
    time.sleep(2)
    print("\nThere are lush trees and flowers within the city mainly around the palace that sits upon a cliff")
    time.sleep(2)
    print("\nAs you walk down the busy streets you over hear some pedestrians talking about some lost treasure that may be out in the meadows to the north")
    time.sleep(2.5)
    print("\n\nWhat to do\n\n1) Search a back alley\n2) Try some local food\n3) Look for the lost treasure\n4) Go back to your ship")
    
    #inorder to find the map you must overhear the conversation about were it is 

    while user_choice2 != "out":
        user_choice2 = input()

        # $200 can be found 1 time here
        if user_choice2 == "1":
            if inventory.ally == True:
                clear()
                print("The alley is clean and even has some planter boxes in the windows")
                time.sleep(2)
                print("\nThere are two incinerators for trash and a short range relay antenna")
                time.sleep(2)
                print("\nBehind one of the incinerators you notice a small brown satchel")
                time.sleep(2)
                print("\nSomeone has dropped there coins here")
                time.sleep(2)
                inventory.money += 200
                inventory.ally = False
                print("\n\n\n+ $200")
                time.sleep(1)
                clear()
                print("The alley is clean and even has some planter boxes in the windows\n\nThere are two incinerators for trash and a short range relay antenna\n\nBehind one of the incinerators you notice a small brown satchel\n\nSomeone has dropped there coins here")
                time.sleep(1)
                print("\n\nWhat to do\n\n1) Search a back alley\n2) Try some local food\n3) Look for the lost treasure\n4) Go back to your ship")
            else:
                clear()
                print("The alley is clean and even has some planter boxes in the windows")
                time.sleep(2)
                print("\nThere are two incinerators for trash and a short range relay antenna")
                time.sleep(2)
                print("\n\nWhat to do\n\n1) Search a back alley\n2) Try some local food\n3) Look for the lost treasure\n4) Go back to your ship")

        #  learn that the map is actually north west by the edge of the meadow instead of strait north

        elif user_choice2 == "2":
            if inventory.money >= 10:
                if inventory.hint == False:
                    clear()
                    print("You get seated and because your not aware of the food on this planet you ask the droid for something simple")
                    time.sleep(2)
                    print("\nYou over hear the table next to you talkin about a map some jedi lost years ago")
                    time.sleep(2)
                    print("\nThey say someone told them some inside information about its location being north west on the edge of the meadow instead of in the middle")
                    time.sleep(2)
                    print("\nYour food arrives, it looks like pancakes and fries") #anakin and padme had this on the naboo commercial transport
                    inventory.hint = True
                    time.sleep(1.5)
                    print("\nWith this new information you eat your food and pay the droid for the meal")
                    time.sleep(2)
                    print("\n\n\n- $10")
                    inventory.money -= 10
                    time.sleep(1.5)
                    clear()
                    print("You get seated and because your not aware of the food on this planet you ask the droid for something simple\n\nYou over hear the table next to you talkin about a map some jedi lost years ago\n\nThey say someone told them some inside information about its location being north west on the edge of the meadow instead of in the middle\n\nYour food arrives, it looks like pancakes and fries\n\nWith this new information you eat your food and pay the droid for the meal")
                    print("\n\nWhat to do\n\n1) Search a back alley\n2) Try some local food\n3) Look for the lost treasure\n4) Go back to your ship")

                else:
                    clear()
                    print("You order the same pancakes and fries you had last time")
                    time.sleep(2)
                    print("\nThe food vanishes quickly, you must have been hungry")
                    time.sleep(2)
                    print("\nYou thank the droid for the food and pay for your meal")
                    time.sleep(1.5)
                    print("\n\n\n- $10")
                    inventory.money -= 10
                    time.sleep(1.5)
                    clear()
                    print("You order the same pancakes and fries you had last time\n\nThe food vanishes quickly, you must have been hungry\n\nYou thank the droid for the food and pay for your meal")
                    print("\n\nWhat to do\n\n1) Search a back alley\n2) Try some local food\n3) Look for the lost treasure\n4) Go back to your ship")


            else:
                clear()
                print("As you walk into the restaurant you realize you don't have any money to pay for a meal")
                time.sleep(2)
                print("\nTry and come back with some money")
                time.sleep(1)
                print("\n\nWhat to do\n\n1) Search a back alley\n2) Try some local food\n3) Look for the lost treasure\n4) Go back to your ship")

        #you must have more info first otherwise you won't find anything
        elif user_choice2 == "3":
            if inventory.hint == True:
                clear()
                print("You travel to the northern border of the city, and head out north west following the information you heard at the restaurant")
                time.sleep(2)
                print("\nAfter about 3 hours of walking you come across a meadow with a river snaking around the west side")
                time.sleep(2)
                print("\nIn the meadow you see several shaak a fat bent over cow like creature")
                time.sleep(2)
                print("\nAlong the bank of the river you see a glint of something metal in the grass")
                time.sleep(2)
                print("\nIts the map you were looking for, and charts out a path to Ilum in the unknown regions of spacee")
                time.sleep(2)
                inventory.unknown_map = True
                print("\n\n\n+ Map of the unknown regions")
                time.sleep(1.5)
                clear()
                print("You travel to the northern border of the city, and head out north west following the information you heard at the restaurant\n\nAfter about 3 hours of walking you come across a meadow with a river snaking around the west side\n\nIn the meadow you see several shaak a fat bent over cow like creature\n\nAlong the bank of the river you see a glint of something metal in the grass\n\nIts the map you were looking for, and charts out a path to Ilum in the unknown regions of space")
                print("\n\nWhat to do\n\n1) Search a back alley\n2) Try some local food\n3) Look for the lost treasure\n4) Go back to your ship")

            #if you dont have the right info
            else:
                clear()
                print("You travel to the northern border of the city, and continue north")
                time.sleep(2)
                print("\nAfter about 3 hours of walking you come across a large meadow surrounded by mountains")
                time.sleep(2)
                print("\nAs you walk into the middle of the meadow some creatures flee")
                time.sleep(2)
                print("\nYou search for hours and don't find anything")
                time.sleep(1.5)
                print("\nOn your way back you think maybe your missing some information, perhaps a meal will help you think")
                time.sleep(2)
                print("\n\nWhat to do\n\n1) Search a back alley\n2) Try some local food\n3) Look for the lost treasure\n4) Go back to your ship")

        #back to room travel
        elif user_choice2 == "4":
            clear()
            print("You head back to the ship hanger")
            time.sleep(2)
            print("Naboo")
            print("\n\nWhat to do\n\n1) Fly to Mustafar\n2) Fly to Tatooine\n3) Look around")
            user_choice2 = "out"

        else:
            print("\nNot a valid input")
                    



            

                        ###        Ilum Getting a kyber crystal        ###

def ilum_puzzle(user_name):
    clear()
    print("Infront you you across an ice plane you see a large door that at is height reaches the top of cliff wall around 100 feet tall")
    time.sleep(2)
    print("\nYou enter the temple just before dawn and find a large room with a frozen waterfall at the other side and two hooded statues facing the center of the room")
    time.sleep(3)
    if inventory.kyber_crystal == False:
        print("\nAs the sun starts to rize it shines through a crystal in the roof of the hall")
        time.sleep(2)
        print("\nA beam of light is cast upon the frozen waterfall, and the water fall begins to melt revealing a cave system behind it")
        time.sleep(2)
        print("\nAs you walk into the cave you see the walls are lined with crystals but none seem right so you continue to go deeper into the cave")
        time.sleep(2)
        print("\nEventually you come across a crystal that appears to be singing to you")
        time.sleep(2)
        print("\n\n\n+ 1 kyber crystal")
        inventory.kyber_crystal = True
        time.sleep(1.5)
        clear()
        print("Infront you you across an ice plane you see a large door that at is height reaches the top of cliff wall around 100 feet tall\n\nYou enter the temple just before dawn and find a large room with a frozen waterfall at the other side and two hooded statues facing the center of the room\n\nAs the sun starts to rize it shines through a crystal in the roof of the hall\n\nA beam of light is cast upon the frozen waterfall, and the water fall begins to melt revealing a cave system behind it\n\nAs you walk into the cave you see the walls are lined with crystals but none seem right so you continue to go deeper into the cave\n\nEventualy you come across a crystal that appears to be singing to you")
        print("Ilum")
        print("\n\nWhat to do\n\n1) Fly to Coruscant\n2) Look around")   

    else:
        print("\nYou ponder who built this place and what it was used for")
        time.sleep(2)
        print("Ilum")
        print("\n\nWhat to do\n\n1) Fly to Coruscant\n2) Look around")  







                        ###        Kashyyk training arena        ###
        
def kashyyk_puzzle(user_name):
    clear()

    user_choice2 = None
    #first time dialogue
    if inventory.intro == False:
        print("As you walk around the dense forest the wookies appear to have made their homes up in the trees")
        time.sleep(2)
        print("\nThese trees are very large and can support multiple houses in the branches")
        time.sleep(2)
        print("\nYou are approached by a blond human, she has blue eyes and is wearing a sand colored jedi robes")
        time.sleep(2)
        print("\nMy name is Siri Tachi and I felt you coming. You have a strong connection to the force")
        time.sleep(2)
        print("\nIf you wish, I will train you. Head south to the mountains so if you wish to begin your training")
        time.sleep(2)
        inventory.intro = True
        print("\n\nWhat to do\n\n1) Head south and begin your training\n2) Look around this area\n3) Go back to your ship")
    
    #all other times 
    else:
        print("You renter the village under the trees")
        time.sleep(2)
        print("\n\nWhat to do\n\n1) Head south to the training temple\n2) Look around this area\n3) Go back to your ship")

    while user_choice2 != "out":
        user_choice2 = input()

        if user_choice2 == "1":
            #first time visit
            if inventory.siri == False:
                clear()
                print("As you get to the base of the mountains you notice about half way up a temple that feels like it is connected to the force")
                time.sleep(2)
                print("\nArriving at the temple you see Siri is already there and is meditating and engraved on the wall is\n\nThere is no emotion, there is peace.\nThere is no ignorance, there is knowledge.\nThere is no passion, there is serenity.\nThere is no chaos, there is harmony.\nThere is no death, there is the Force.")
                time.sleep(2)
                print("\nAhhhhh you came... So who might you be? {} You reply".format(user_name))
                time.sleep(2)
                print("\nWelcome {}, here I can help you practice in a safe environment".format(user_name))
                time.sleep(2)
                print("\nHere all the training targets are the same as your level")
                time.sleep(2)
                print("\n\nWhat to do\n\n1) Enter the training room\n2) Learn how combat works\n3) Go back to the village under the trees")
            #all other visits
            else:
                clear()
                print("Welcome back {}, have you come back to learn more about the jedi ways".format(user_name))
                time.sleep(2)
                print("\nJust remember in here all the training targets are the same as your level")
                time.sleep(2)
                print("\n\nWhat to do\n\n1) Enter the training room\n2) Learn how combat works\n3) Go back to the village under the trees")


            user_choice3 = None
            while user_choice3 != "out":
                user_choice3 = input()

                if user_choice3 == "1":
                    clear()
                    if inventory.lightsaber == True:
                        print("You enter the training hall\n")
                        training_drill()
                        print("\n\nWhat to do\n\n1) Enter the training room\n2) Learn how combat works\n3) Go back to the village under the trees")
                    else:
                        print("Siri tells you that you must first construct a lightsaber in order to train")
                        time.sleep(2)
                        print("\nIn order to construct a lightsaber you will need to find 4 iron, 6 aluminum, 2 titanium and a kyber crystal")
                        time.sleep(2)
                        print("\nTo find a kyber crystal you must first find a map to the planet Ilum")
                        time.sleep(2)
                        print("\n\nWhat to do\n\n1) Enter the training room\n2) Learn how combat works\n3) Go back to the village under the trees")

                elif user_choice3 == "2":
                    clear()
                    print("First you will pick one enemy to attack")
                    time.sleep(2)
                    print("Then select a attack")
                    time.sleep(1)
                    print("You will unlock more abilities as you level up")
                    time.sleep(2)
                    print("\n\nWhat to do\n\n1) Enter the training room\n2) Learn how combat works\n3) Go back to the village under the trees")

                elif user_choice3 == "3":
                    clear()
                    print("You go back to the village under the trees")
                    time.sleep(2)
                    print("\n\nWhat to do\n\n1) Head south to the training temple\n2) Look around this area\n3) Go back to your ship")
                    user_choice3 = "out"
                    



            
        #find some money
        elif user_choice2 == "2":
            if inventory.forest == True:
                clear()
                print("As you begin to search the area you see a glint in the grass")
                time.sleep(2)
                print("\nOne of the Wookies must have dropped these coins from there treehouse")
                time.sleep(2)
                print("\n\n\n+ $100")
                inventory.money += 100
                inventory.forest = False
                time.sleep(1.5)
                clear()
                print("As you begin to search the area you see a glint in the grass\n\nOne of the Wookies must have dropped these coins from there treehouse")
                print("\n\nWhat to do\n\n1) Head south and begin your training\n2) Look around this area\n3) Go back to your ship")
                
            else:
                clear()
                print("You don't find anything")
                time.sleep(2)
                print("\n\nWhat to do\n\n1) Head south and begin your training\n2) Look around this area\n3) Go back to your ship")

        elif user_choice2 == "3":
            clear()
            print("You go back to your ship")
            time.sleep(2)
            print("Kashyyk")
            print("\n\nWhat to do\n\n1) Fly to Coruscant\n2) Fly to Formos\n3) Look around")
            user_choice2 = "out"

        else:
            print("\nNot a valid input")









            ###            Hoth description and boss battle            ###


          
def hoth_puzzle(user_name):
    clear()
    print("You look all around and see snow, snow, more snow")
    time.sleep(2)
    print("\nBy the snow mountain made of snow you feel a dark presence in a cave")
    time.sleep(2)
    print("\n\nWhat to do\n\n1) Investigate the cave\n2) Build a snowman\n3) Go back to your ship")
    user_choice2 = None

    while user_choice2 != "out":
        user_choice2 = input()
        clear()
        #must be lev 10 to win
        if inventory.lightsaber == True and user_choice2 == "1":
            print("You enter The cave and see a human dressed in a flowing all black cloak with yellow glowing bloodshot eyes")
            boss_outcome = boss_battle(user_name)
            if boss_outcome == True:
                return True
                user_choice2 = "out"
            elif boss_outcome == False:
                inventory.health = 100 * inventory.user_level
                print("You respawn back on hoth")
                time.sleep(2)
                print("\n\nWhat to do\n\n1) Investigate the cave\n2) Build a snowman\n3) Go back to your ship")
        elif inventory.lightsaber == False and user_choice2 == "1":
            print("You need a lightsaber for this area")
            time.sleep(2)
            print("\n\nWhat to do\n\n1) Investigate the cave\n2) Build a snowman\n3) Go back to your ship")

        #snowman
        elif user_choice2 == "2":
            print("You roll a large base, two smaller parts you look around for anything to add for limbs and a mouth and nose")
            time.sleep(2)
            print("\nAfter a quick search you realize that there is nothing here but snow")
            time.sleep(2)
            print("\nYou are going to have to leave the snowman half done :(")
            time.sleep(2)
            print("\n\nWhat to do\n\n1) Investigate the cave\n2) Build a snowman\n3) Go back to your ship")

        elif user_choice2 == "3":
            print("You head back to you ship")
            time.sleep(2)
            print("Hoth")
            print("\n\nWhat to do\n\n1) Fly to Mustafar\n2) Fly to Coruscant\n3) Look around")
            return False
            user_choice2 = "out"


#### scraped as the idea no longer fits with the naritave

def kessel_puzzle(user_choice):
    clear()

    user_choice2 = None
    print("what you find")
    #time trial      Try a for loop for lev * numb
    #time is base on actions 
    #time amount is base on user level