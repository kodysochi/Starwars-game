import time
import random
import inventory
from inventory import training_health
from console_functions import clear


                ###            XP             ###

def give_xp(xp):
    inventory.xp += xp
    x = 0
    while x == 0:
        if inventory.xp >= inventory.user_level * 2 + 100:
            inventory.user_level += 1
            inventory.xp -= inventory.user_level * 2 + 100
            print("\n\n\nLevel Up\n\nYou are now level {}".format(inventory.user_level))
            if inventory.user_level * 2 + 100 <= inventory.xp:
                x = 1
            if inventory.user_level >= 20 and inventory.kyber_crystal_color != "green":
                inventory.kyber_crystal_color = "green"
                print("You have become a jedi master\nyour lightsaber now shines green")

        else:
            x = 1


            
#Target is the enemy the user picked to attack
def user_attacks(target):
    attack_input = None
    while attack_input != "out":
        print("\n\nTo get a description of the attack type out the name of the attack with a capital at the start of each word")
        if 1 <= inventory.user_level < 5:
            print("\n1) Slash")
        elif 5 <= inventory.user_level < 10:
            print("\n1) Slash\n2) Lunge")
        elif 10 <= inventory.user_level < 15:
            print("\n1) Slash\n2) Lunge\n3) Quick Attack")
        elif 15 <= inventory.user_level:
            print("\n1) Slash\n2) Lunge\n3) Quick Attack\n4) Passata Sotto")
        attack_input = input()

        #Attack description
        if attack_input == "Slash":
            print("A single large arking motion with the intent to slice through your opponent")
            attack_input = input()
        elif attack_input == "Lunge":
            print("Jumping forward in a stabbing motion")
            attack_input = input()
        elif attack_input == "Quick Attack":
            print("A series of fast blitz attack counting 3 in total")
            attack_input = input()
        elif attack_input == "Passata Sotto":
            print("Evade your opponent’s attack by dropping your body beneath his or her weapon, placing your free hand on the ground for support and balance. As your opponent looms over you, straighten your sword arm and attempt to stab your adversary")
            attack_input = input()

        
        #doing the damage
        #slash
        if attack_input == "1":
            if 1 <= inventory.user_level < 5:
                target -= 25 + (inventory.user_level * 5)
                print("\n\nYou did {} damage".format(25 + (inventory.user_level * 5)))
                return target
                attack_input = "out"
            elif 5 <= inventory.user_level < 10:
                target -= 50 + (inventory.user_level * 5)
                print("\n\nYou did {} damage".format(50 + (inventory.user_level * 5)))
                return target
                attack_input = "out"
            elif 10 <= inventory.user_level < 15:
                target -= 100 + (inventory.user_level * 5)
                print("\n\nYou did {} damage".format(100 + (inventory.user_level * 5)))
                return target
                attack_input = "out"
            elif 15 <= inventory.user_level < 20:
                target -= 200 + (inventory.user_level * 5)
                print("\n\nYou did {} damage".format(200 + (inventory.user_level * 5)))
                return target
                attack_input = "out"
            elif 20 < inventory.user_level:
                target -= 400 + (inventory.user_level * 5)
                print("\n\nYou did {} damage".format(400 + (inventory.user_level * 5)))
                return target
                attack_input = "out"
            else:
                print("Not a valid input")
            return target
            

        #lunge
        elif attack_input == "2":
            if 5 <= inventory.user_level < 10:
                target -= 75 + (inventory.user_level * 4)
                print("\n\nYou did {} damage".format(75 + (inventory.user_level * 4)))
                return target
                attack_input = "out"
            elif 10 <= inventory.user_level < 15:
                target -= 150 + (inventory.user_level * 4)
                print("\n\nYou did {} damage".format(150 + (inventory.user_level * 4)))
                return target
                attack_input = "out"
            elif 15 <= inventory.user_level < 20:
                target -= 250 + (inventory.user_level * 4)
                print("\n\nYou did {} damage".format(250 + (inventory.user_level * 4)))
                return target
                attack_input = "out"
            elif 20 < inventory.user_level:
                target -= 500 + (inventory.user_level * 4)
                print("\n\nYou did {} damage".format(500 + (inventory.user_level * 4)))
                return target
                attack_input = "out"
            else:
                print("Not a valid input")
            

        #quick attacks
        elif attack_input == "3":
            x = 0
            while x != 3:
                if 10 <= inventory.user_level < 15:
                    target -= 50 + (inventory.user_level * 4)
                    print("\n\nYou did {} damage".format(50 + (inventory.user_level * 4)))
                    x += 1
                elif 15 <= inventory.user_level < 20:
                    target -= 80 + (inventory.user_level * 4)
                    print("\n\nYou did {} damage".format(80 + (inventory.user_level * 4)))
                    x += 1
                elif 20 < inventory.user_level:
                    target -= 150 + (inventory.user_level * 4)
                    print("\n\nYou did {} damage".format(150 + (inventory.user_level * 4)))
                    x += 1
                else:
                    print("Not a valid input")
            return target
            

        #Passata Sotto
        elif attack_input == "4":
            if 15 <= inventory.user_level < 20:
                target -= 200 + (inventory.user_level * 10)
                print("\n\nYou did {} damage".format(200 + (inventory.user_level * 10)))
                return target
                attack_input = "out"
            elif 20 < inventory.user_level:
                target -= 500 + (inventory.user_level * 10)
                print("\n\nYou did {} damage".format(500 + (inventory.user_level * 10)))
                return target
                attack_input = "out"
            else:
                print("Not a valid input")
            
            
            
        else:
            print("Not a valid input")


#####         Training attacks            #####
def training_drill():
# spawn enemies
    target_choice = None
    enemies_numb = random.randint(1, 3)

    if enemies_numb == 1:
        target1 = training_health()
        target2 = 0
        target3 = 0
        print("There is 1 training dummy on the field")
        time.sleep(2)
        print("\n\nWhat enemy would you like to target\n1) Training dummy 1")
    elif enemies_numb == 2:
        target1 = training_health()
        target2 = training_health()
        target3 = 0
        print("There is 2 training dummy on the field")
        time.sleep(2)
        print("\n\nWhat enemy would you like to target\n1) Training dummy 1\n2) Training dummy 2")
    elif enemies_numb == 3:
        target1 = training_health()
        target2 = training_health()
        target3 = training_health()
        print("There is 3 training dummy on the field")
        time.sleep(2)
        print("\n\nWhat enemy would you like to target\n1) Training dummy 1\n2) Training dummy 2\n3) Training dummy 3")

    dead = 0
    while inventory.health > 0 and (target1 > 0 or target2 > 0 or target3 > 0):
        target_choice = input()

        # user goes first
        # cheack enimies health
        # if dead reward xp
        while target_choice != "good":
            if target_choice == "1":
                if target1 > 0:
                    target1 = user_attacks(target1)
                    if target1 <= 0:
                        print("A training dummy has died")
                        print("\n\nYou got {} xp".format(training_health() * 2))
                        give_xp(training_health() * 2)
                        dead += 1
                    else:
                        print("1 Training dummy has {} health left".format(target1))
                    target_choice = "good"
                else:
                    print("Not a valid input")
                    target_choice = input()

            
            elif target_choice == "2":
                if target2 > 0:
                    target2 = user_attacks(target2)
                    if target2 <= 0:
                        print("A training dummy has died")
                        print("\n\nYou got {} xp".format(training_health() * 2))
                        give_xp(training_health() * 2)
                        dead += 1
                    else:
                        print("1 Training dummy has {} health left".format(target2))
                    target_choice = "good"
                else:
                    print("Not a valid input")
                    target_choice = input()

            elif target_choice == "3":
                if target3 > 0:
                    target3 = user_attacks(target3)
                    if target3 <= 0:
                        print("A training dummy has died")
                        print("\n\nYou got {} xp".format(training_health() * 2))
                        give_xp(training_health() * 2)
                        dead += 1
                    else:
                        print("1 Training dummy has {} health left".format(target3))
                    target_choice = "good"
    
                else:
                    print("Not a valid input")
                    target_choice = input()
    
            else:
                print("Not a valid input")
                target_choice = input()
    
        time.sleep(2)
        if (enemies_numb - dead) > 0:
            for i in range(enemies_numb - dead):
                inventory.health -= 20 * inventory.user_level
                print("You took {} points of damage from a training dummy and have {} health left".format(20 * inventory.user_level, inventory.health))
                if inventory.health <= 0:
                    print("you died")
                    break
                else:
                    print("")
        else:
            print("")

        #continuing the attack
        if inventory.health > 0:
            
            if target1 > 0 or target2 > 0 or target3 > 0:
                print("\n\nWhat enemie would you like to target\n")
                
            if target1 > 0:
                print("1) Training dummy 1")
            
    
            if target2 > 0:
                print("2) Training dummy 2")
      
    
            if target3 > 0:
                print("3) Training dummy 3")

    #reset health
    inventory.health = 100 * inventory.user_level






                ##########            Boss Battle            #########

def boss_battle(user_name):
    #clear()
    boss_health = 2000
    boss_dead = False
    #damage ~ 60 - 90 for 12 - 15 rounds at lev 10

    print("\nOhhh? You're approaching me?")
    time.sleep(2)
    print("\nHis arms are outstretched by his waist in a beckoning taunting manner")
    time.sleep(2)
    print("\nIn response you ignite your {} lightsaber".format(inventory.kyber_crystal_color))
    time.sleep(2)
    print("\nHe responds by igniting a menacing red blade")
    while boss_dead != True and inventory.health > 0:
        #user attack
        boss_health = user_attacks(boss_health)
        print("The boss has {} health remaining".format(boss_health))
        time.sleep(1)
        if boss_health <= 0:
            #clear()
            print("The sith Falls to his knees")
            time.sleep(2)
            print("\nYou reach out in the force and the siths lightsaber flies to your hand")
            time.sleep(2)
            return True
            boss_dead = True

            
        #boss attack
        boss_attack = random.randint(1, 4)
        if boss_attack == 1:
            print("\nThe sith swings his saber through the air with immense force and connects a powerful slashing attack")
            inventory.health -= 60
            time.sleep(2)
            print("\nYou take 60 points of slashing damage and have {} health remaining".format(inventory.health))
            if inventory.health <= 0:
                clear()
                print("Seeing you stagger the sith sees an opportunity")
                time.sleep(2)
                print("\nHe lifts you up with his fingers in a pinching position you feel him closing your windpipe")
                time.sleep(2)
                print("\nYour Windpipe gets crushed and you crumble to the floor")
                time.sleep(1)
                print("\n\n\n            YOU DIE")
                return False
        
        if boss_attack == 2:
            print("\nThe sith forward thrusting his saber towards you")
            inventory.health -= 70
            print("\nYou take 70 points of stabbing damage and have {} health remaining".format(inventory.health))
            if inventory.health <= 0:
                clear()
                print("\nYou were a little too slow with that last attack and the siths saber drills into your chest")
                time.sleep(2)
                print("\nIn a lot of pain you drop to both knees dropping you lightsaber to the floor")
                time.sleep(2)
                print("\nThe sith slowly picks up your light saber and using both cuts your head off")
                time.sleep(1)
                print("\n\n\n            YOU DIE")
                time.sleep(5)
                return False

        if boss_attack == 3:
            print("\nThe sith Force pushes you against the icy walls in the cave")
            inventory.health -= 80
            print("\nYou take 80 points of stabbing damage and have {} health remaining".format(inventory.health))
            if inventory.health <= 0:
                clear()
                print("\nAs you fall from the wall the sith lunges in your direction")
                time.sleep(2)
                print("\nHe slices you perfectly in half from head to toe")
                time.sleep(1)
                print("\n\n\n            YOU DIE")
                time.sleep(5)
                return False

        if boss_attack == 4:
            print("\nThe sith uses the force to detach a large icy stalactite from the ceiling of the cave and throws it at you")
            inventory.health -= 90
            print("\nYou take 90 points of stabbing damage and have {} health remaining".format(inventory.health))
            if inventory.health <= 0:
                clear()
                print("\nAfter slicing that stalactite in half you realize the sith has thrown more")
                time.sleep(2)
                print("\nYou cut through two more however the other five impale themselves into your chest")
                time.sleep(1)
                print("\n\n\n            YOU DIE")
                time.sleep(5)
                return False