import os
import sys
import time


def clear():
	os.system("clr" if os.name == "nt" else "clear")

def quit():
    sys.exit()
