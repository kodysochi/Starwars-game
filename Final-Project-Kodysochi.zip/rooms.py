import time
from console_functions import clear
from puzzle import tatooine_puzzle, hoth_puzzle, coruscant_puzzle, kessel_puzzle, mustafar_puzzle, naboo_puzzle, ilum_puzzle, kashyyk_puzzle
import inventory


                                ###            Coruscant            ###

def coruscant (user_name):
    clear()
    
    print("Coruscant is like one giant city. The entire planet is filled with skyscrapers, and underneath the top level is more city. Down in the lower levels of the planet is a large criminal underworld and most who are born there never see the sun. Lucky for you, you live in a scraper on the top layer with a luxurious view of the sky.")
    user_choice = None
    print("\n\n\nCoruscant")
    if inventory.unknown_map == False:
        print("\n\nWhat to do\n\n1) Fly to Hoth\n2) Fly to Kashyyk\n3) Fly to Tatooine\n4) Fly to Mustafar\n5) Enter appartment")
    else:
        print("\n\nWhat to do\n\n1) Fly to Hoth\n2) Fly to Kashyyk\n3) Fly to Tatooine\n4) Fly to Mustafar\n5) Enter appartment\n6) Fly into the unknown regions to Ilum")
    while user_choice != "quit":
        user_choice = input()

        if user_choice == "1":
            clear()
            print("You jump to hyperspace following the Corellian Trade Spine split of the Corellian run south to the Anoat Sector in the outer rim")
            time.sleep(5)
            hoth (user_name)
        elif user_choice == "2":
            clear()
            print("You jump to hyperspace following the Perlimian Trade Route east and the Randon Run south ariving in the Mytaranor Sector in the mid rim")
            time.sleep(5)
            kashyyk(user_name)
        elif user_choice == "3":
            clear()
            print("You jump to hyperspace following the Corellian Run south to the Arkanis Sector in the outer rim")
            time.sleep(5)
            tatooine(user_name)
        elif user_choice == "4":
            clear()
            print("You jump to hyperspace following the Hydian Way south to the Artavis Sector in the outer rim")
            time.sleep(5)
            mustafar(user_name)
        elif user_choice == "5":
            coruscant_puzzle(user_name)
        elif user_choice == "6" and inventory.unknown_map == True:
            ilum(user_name)
        elif user_choice == "quit":
            clear()
            print("\n\nSee you next time\n\n")
            quit()
        else:
            print("Not a valid input")




                                  ###            Hoth            ###

def hoth (user_name):
    clear()

    print("Hoth is a planet of ice and snow. The planet is filled with glacier fields, icy mountains with caves and ravines. There are few native species on this planet due to the cold temperatures that can reach -76 F at night. Rumor has it that there is an old abandoned rebel base on this planet but the location is unknown to you.")
    user_choice = None
    print("\n\n\nHoth")
    print("\n\nWhat to do\n\n1) Fly to Mustafar\n2) Fly to Coruscant\n3) Look around")

    while user_choice != "quit":
        user_choice = input()

        if user_choice == "1":
            clear()
            print("You jump to hyperspace following the Northoiin Corridor east and the Hydian Way south to the Artavis Sector in the outer rim")
            time.sleep(5)
            mustafar(user_name)
        elif user_choice == "2":
            clear()
            print("You jump to hyperspace following the Corellian Trade Spine split of the Corellian run to the Coruscant System in the Core worlds")
            time.sleep(5)
            coruscant(user_name)
        elif user_choice == "3":
            outcome = hoth_puzzle(user_name)
            if outcome == True:
                print("Swinging you lightsaber around you quickly cut of the siths head providing the quickest death you could")
                time.sleep(2)
                print("\n\n\nCONGRADULATIONS you win")
                time.sleep(10)
                quit()
        elif user_choice == "quit":
            clear()
            print("\n\nSee you next time\n\n")
            quit()
        else:
            print("Not a valid input")





                                ###            Mustafar            ###

def mustafar(user_name):
    clear()

    print("Mustafar is a small planet that glows red from its large lava oceans that cover most of the surface. Despite the lava there are large factories and forages that use the heat of the planet to melt metal and forage items. Most are abandoned old reminets from the old galactic wars. The land is all balck volcanic rock.")
    user_choice = None
    print("\n\n\nMustafar")
    print("\n\nWhat to do\n\n1) Fly to Hoth\n2) Fly to Coruscant\n3) Fly to Naboo\n4) Look around")

    while user_choice != "quit":
        user_choice = input()

        if user_choice == "1":
            clear()
            print("You jump to hyperspace following the Hydian Way north and the Northoiin Corridor west to the Anoat Sector in the outer rim")
            time.sleep(5)
            hoth(user_name)
        elif user_choice == "2":
            clear()
            print("You jump to hyperspace following the Hydian Way north to the Coruscant system in the core worlds")
            time.sleep(5)
            coruscant(user_name)
        elif user_choice == "3":
            clear()
            print("You jump to hyperspace following the Hydian Way north and the Triellus Trade Route east to the Chommel Sector in the mid rim")
            time.sleep(5)
            naboo(user_name)
        elif user_choice == "4":
            mustafar_puzzle(user_name)
        elif user_choice == "quit":
            clear()
            print("\n\nSee you next time\n\n")
            quit()
        else:
            print("not a valid input")






                                ###            Naboo            ###

def naboo(user_name):
    clear()

    print("Naboo is a well sized planet with large meadows, mountains, forest and large oceans with sprawling underwater caves. It was home to the indigenous Gungan species and to a population of humans known as the Naboo. ")
    user_choice = None
    print("\n\n\nNaboo")
    print("\n\nWhat to do\n\n1) Fly to Mustafar\n2) Fly to Tatooine\n3) Look around")
    
    
    while user_choice != "quit":
        user_choice = input()

        if user_choice == "1":
            clear()
            print("You jump to hyperspace following the Triellus Trade Route west and the Hydian Way south to the Atravis Sector in the outer rim")
            time.sleep(5)
            mustafar(user_name)
        elif user_choice == "2":
            clear()
            print("You jump to hyperspace following the Triellus Trade Route east to Arkanis Sector in the outer rim")
            time.sleep(5)
            tatooine(user_name)
        elif user_choice == "3":
            naboo_puzzle(user_name)
        elif user_choice == "quit":
            clear()
            print("\n\nSee you next time\n\n")
            quit()
        else:
            print("not a valid input")





                                ###            Tatooine            ###

def tatooine(user_name):
    clear()

    print("Tatooine is a large desert planet with large sand oceans and dry rocky mountains. The planet has no surface water. As a result, many residents of the planet instead drew water from the atmosphere via moisture farms. Due to a lack of laws and governing bodies the area has become a haven for smuggler and criminal activity.")
    user_choice = None
    print("\n\n\nTatooine")
    print("\n\nWhat to do\n\n1) Fly to naboo\n2) Fly to Coruscant\n3) Fly to Formos\n4) Look around")
   
    
    while user_choice != "quit":
        user_choice = input()

        if user_choice == "1":
            clear()
            print("You jump to hyperspace following the Triellus Trade Route west to the Chommel Sector in the mid rim")
            time.sleep(5)
            naboo(user_name)
        elif user_choice == "2":
            clear()
            print("You jump to hyperspace following the Corellian Run north to the Coruscant system in the Core worlds")
            time.sleep(5)
            coruscant(user_name)
        elif user_choice == "3":
            clear()
            print("You jump to hyperspace following the Triellus Trade Route north to the Kessel Sector in the outer rim")
            time.sleep(5)
            formos(user_name)
        elif user_choice == "4":
            tatooine_puzzle(user_name)
        elif user_choice == "quit":
            clear()
            print("\n\nSee you next time\n\n")
            quit()
        else:
            print("not a valid input")




                                ###            Formos            ###

def formos(user_name):
    clear()

    print("Formos is a dry sandy planet near the panet kessal. Because of this it became a hideout for people smuggling spice from kessal and a target to pirates trying to steal the spice.")
    user_choice = None
    # print("Formos\n\nYou begin to feel something strong trying to connect with you in the force. It feels like it is using both sides of the force")
    print("\n\n\nFormos")
    print("\n\nWhat to do\n\n1) Fly to Tatooine\n2) Fly to Kashyyk\n3) Look around")
    
    
    while user_choice != "quit":
        user_choice = input()

        if user_choice == "1":
            clear()
            print("You jump to hyperspace following the Triellus Trade Route south to the Arkanis Sector in the outer rim")
            time.sleep(2)
            tatooine(user_name)
        elif user_choice == "2":
            clear()
            print("You jump to hyperspace following the Pabol Sleheyron west and the Randon Run north to the Mytaranor Sector in the mid rim")
            time.sleep(2)
            kashyyk(user_name)
        # elif user_choice == "3":
        #     clear()
        #     print("You enter the Kessel Run flying quickly towrds Kessel")
        #     time.sleep(2)
        #     print("\nYou reconize that what ever this being is that is reaching out in the force is trying to enter your mind.")
        #     time.sleep(2)
        #     print("\nThe closer you get to Kessel the stronger this feeling gets")
        #     time.sleep(2)
        #     kessel(user_name)
        elif user_choice == "3":
            clear()
            print("Most things seem broken destroyed by gunfire")
            time.sleep(2)
            print("This planet has nothing left after years of pirate raids on the spice trade")
            time.sleep(2)
            print("\n\nWhat to do\n\n1) Fly to Tatooine\n2) Fly to Kashyyk\n3) Look around")
            
        elif user_choice == "quit":
            clear()
            print("\n\nSee you next time\n\n")
            quit()
        else:
            print("not a valid input")





                                ###            Kashyyk            ###

def kashyyk(user_name):
    clear()

    print("Kashyyk is a tropical jungle planet covered in wroshyr trees. Kashyyyk served as homeworld to the Wookiee species. Who built their homes in the large trees. The center of the planet was a tropical ocean belt with numerous islands and coral reefs.")
    user_choice = None
    print("\n\n\nKashyyk")
    print("\n\nWhat to do\n\n1) Fly to Coruscant\n2) Fly to Formos\n3) Look around")


    while user_choice != "quit":
        user_choice = input()

        if user_choice == "1":
            clear()
            print("You jump to hyperspace following the Randon Run north and the Perlimian Trade Route west to the Coruscant System in the core worlds")
            time.sleep(5)
            coruscant(user_name)
        elif user_choice == "2":
            clear()
            print("You jump to hyperspace following the Randon Run south and the Pabol Sleheyron east to the Kessel Sector in the outer rim")
            time.sleep(5)
            formos(user_name)
        elif user_choice == "3":
            kashyyk_puzzle(user_name)
        elif user_choice == "quit":
            clear()
            print("\n\nSee you next time\n\n")
            quit()
        else:
            print("not a valid input")




                                ###            Kessel            ###

# def kessel(user_name):
#     clear()

#     user_choice = None
#     print("1) Go back still testing")


#     while user_choice != "quit":
#         user_choice = input()

#         if user_choice == "1":
#             formos(user_name)
#         elif user_choice == "2":
#             #planet loop/ timer
#             print("testing")
#         elif user_choice == "quit":
#             clear()
#             print("\n\nSee you next time\n\n")
#             quit()
#         else:
#             print("not a valid input")





                                ###            Ilum            ###

def ilum(user_name):
    clear()

    print("Ilum is a snow covered planet in the unknown regions of space. During the galactic empire's rule the planet was mined for its kyber crystal core by the imperials causing it to have a large trench around the equator.")
    user_choice = None
    print("Ilum")
    print("\n\nWhat to do\n\n1) Fly to Coruscant\n2) Look around")

    while user_choice != "quit":
        user_choice = input()

        if user_choice == "1":
            coruscant(user_name)
        elif user_choice == "2":
            ilum_puzzle(user_name)
        elif user_choice == "quit":
            clear()
            print("\n\nSee you next time\n\n")
            quit()
        else:
            print("not a valid input")