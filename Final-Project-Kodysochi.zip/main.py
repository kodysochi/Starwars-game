# Tyler Harned
# A Star Wars game
from rooms import coruscant
import time



def main():

    print("\nYou live on the plant of Coruscant in an apartment high in a skyscraper")
    time.sleep(2)
    print("\nFor the past few years you have started to feel connections to living things")
    time.sleep(2)
    print("\nAs this feeling gets stronger you learn its the force")
    time.sleep(2)
    print("\nIn search of answers to what this force is you decide to set out on an adventure and will set out on a journey to become a jedi")
    user_name = input("What is your name?\n\n")
    coruscant(user_name)
    

main()

