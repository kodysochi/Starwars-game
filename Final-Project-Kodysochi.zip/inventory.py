#currency
money = 0

#resorses
iron = 0
aluminium = 0
titanium = 0
melon = 0

#artifacts
unknown_map = False
picture = False
lightsaber = False


#lightsaber parts
lightsaber_handle = 0     #you need 2 inorder to sorround the kyber crystal 
kyber_crystal = False
kyber_crystal_color = ""


                #Things to find#
#------------------------------------------------------------------#
#coruscant
dresser = True

#Naboo
ally = True
hint = False

#kashyyk
intro = False
forest = True
siri = False


                #player level
#------------------------------------------------------------------#
user_level = 1
xp = 0
health = 100 * user_level



                #Hostiles base stats
#-------------------------------------------------------------------#
def training_health():
    return 25 * (user_level * .75)