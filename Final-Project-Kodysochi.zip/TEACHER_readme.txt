
each def function is seperated by

            ###            short description             ###

combat.py 
    has xp handling/level up
    has training combat
    has boss battle

inventory 
    has your inventory and world inventory/variables


console_functions 
    has clear concole
    has sys.exit

puzzle.py 
    has each worlds functions if they need the extra room to do something

rooms.py
    is were the game loop base area is 

starwars map 
    I drew over a interactable map to show what areas and routs im using in this game

recomended level for boss fight is 10-12


Trough extended testing i found that if replit disconects and recondects it brakes the loop and i have not found a way around it